---
title: Begin Preparations
---
Winter is coming.