---
title: Ward Off Evil Spirits
---
They say that there's no such things as monsters, but I know the truth, for I have slept in the woods under the night sky. I know that there are things that lurk for which there are no known explanations.