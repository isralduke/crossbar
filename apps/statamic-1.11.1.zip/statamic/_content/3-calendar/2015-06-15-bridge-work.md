---
title: Bridge Work
---
I traverse the trails, fixing and bridges that have been downed due to a harsh winter.