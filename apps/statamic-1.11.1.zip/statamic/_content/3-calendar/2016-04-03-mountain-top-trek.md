---
title: Mountain Top Trek
---
Once a year I summit the mountain to survey the lands on which I survive to take an assessment of glens, rivers, nests of every kind, and other useful natural structures.