---
title: Calendar
_fieldset: page
_template: calendar
---
Many things are happening this year, assuming I remain alive. Given this hopeful but certainly not inevitable outcome, here lies the highlights of the upcoming years. May they bring happiness, and a sense of calm within.