---
title: Basic Shelter
_template: section
---
The most rudimentary of temporary structures. To be used in emergencies.