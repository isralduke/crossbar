---
title: A Warm Thought on a Cold Night
categories:
  - wilderness
  - cold
---
> Were I to die tonight, I'd be more of a man tomorrow.