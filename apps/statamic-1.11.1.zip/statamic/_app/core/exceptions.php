<?php

class ResourceNotFoundException extends Exception {}

class FatalException extends Exception {}

class DecryptException extends Exception {}