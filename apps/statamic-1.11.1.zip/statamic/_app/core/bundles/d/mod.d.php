<?php

class Modifier_d extends Modifier
{
    public function index($value, $parameters=array())
    {
        d($value);
    }
}
