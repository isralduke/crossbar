# Raven: The only form solution you'll ever need.

## Installing
1. Drop the add-ons/raven folder into the `/_add-ons/` folder.
2. Drop the _config/add-ons/raven/ folder into `/_config/add-ons/`.
3. Drop the _config/formsets/ folder into `/_config`. Or create your own.
4. Start flying!

## Docs
<http://statamic.com/add-ons/raven>